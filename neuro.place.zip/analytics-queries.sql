-- Analytics Engine SQL Queries for Pixel Placement Data
-- Dataset: user_actions

-- 1. Total pixel placements per day
SELECT
    intDiv(toUInt32(timestamp), 86400) * 86400 AS day,
    COUNT(*) AS total_placements,
    COUNT(DISTINCT indexes[1]) AS unique_users
FROM user_actions
WHERE blob1 = 'pixel_placement'
    AND timestamp >= NOW() - INTERVAL '30' DAY
GROUP BY day
ORDER BY day DESC;

-- 2. Device type breakdown
SELECT
    blob2 AS device_type,
    COUNT(*) AS placements,
    COUNT(DISTINCT indexes[1]) AS unique_users,
    AVG(double3) AS avg_time_to_first_placement_ms
FROM user_actions
WHERE blob1 = 'pixel_placement'
    AND timestamp >= NOW() - INTERVAL '7' DAY
GROUP BY device_type
ORDER BY placements DESC;

-- 3. Input method analysis (spacebar vs button vs touch)
SELECT
    blob3 AS input_method,
    COUNT(*) AS placements,
    COUNT(DISTINCT indexes[1]) AS unique_users,
    ROUND(AVG(double3), 2) AS avg_time_to_first_ms,
    ROUND(AVG(double4), 2) AS avg_session_duration_ms
FROM user_actions
WHERE blob1 = 'pixel_placement'
    AND timestamp >= NOW() - INTERVAL '7' DAY
GROUP BY input_method
ORDER BY placements DESC;

-- 4. Authentication status and user types
SELECT
    blob4 AS auth_status,
    blob5 AS user_type,
    COUNT(*) AS placements,
    COUNT(DISTINCT indexes[1]) AS unique_users
FROM user_actions
WHERE blob1 = 'pixel_placement'
    AND timestamp >= NOW() - INTERVAL '7' DAY
GROUP BY auth_status, user_type
ORDER BY placements DESC;

-- 5. Time to first pixel placement analysis
SELECT
    blob2 AS device_type,
    blob4 AS auth_status,
    ROUND(AVG(double3), 2) AS avg_time_to_first_ms,
    ROUND(quantile(0.5)(double3), 2) AS median_time_to_first_ms,
    ROUND(quantile(0.9)(double3), 2) AS p90_time_to_first_ms,
    COUNT(*) AS placements
FROM user_actions
WHERE blob1 = 'pixel_placement'
    AND double3 > 0  -- Only include records where time to first placement is tracked
    AND timestamp >= NOW() - INTERVAL '7' DAY
GROUP BY device_type, auth_status
ORDER BY avg_time_to_first_ms DESC;

-- 6. Peak usage hours
SELECT
    toHour(timestamp) AS hour_of_day,
    COUNT(*) AS placements,
    COUNT(DISTINCT indexes[1]) AS unique_users,
    ROUND(AVG(double5), 2) AS avg_placement_count_per_session
FROM user_actions
WHERE blob1 = 'pixel_placement'
    AND timestamp >= NOW() - INTERVAL '7' DAY
GROUP BY hour_of_day
ORDER BY hour_of_day;

-- 7. Session duration analysis
SELECT
    blob2 AS device_type,
    ROUND(AVG(double4), 2) AS avg_session_duration_ms,
    ROUND(quantile(0.5)(double4), 2) AS median_session_duration_ms,
    ROUND(AVG(double5), 2) AS avg_placements_per_session
FROM user_actions
WHERE blob1 = 'pixel_placement'
    AND double4 > 0  -- Only sessions with tracked duration
    AND timestamp >= NOW() - INTERVAL '7' DAY
GROUP BY device_type
ORDER BY avg_session_duration_ms DESC;

-- 8. Popular pixel coordinates (heatmap data)
SELECT
    double1 AS x_coordinate,
    double2 AS y_coordinate,
    COUNT(*) AS placement_count
FROM user_actions
WHERE blob1 = 'pixel_placement'
    AND timestamp >= NOW() - INTERVAL '7' DAY
GROUP BY x_coordinate, y_coordinate
HAVING placement_count > 5  -- Filter for hotspots
ORDER BY placement_count DESC
LIMIT 100;

-- 9. User engagement metrics
SELECT
    indexes[1] AS user_id,
    blob2 AS device_type,
    blob5 AS user_type,
    COUNT(*) AS total_placements,
    ROUND(AVG(double4), 2) AS avg_session_duration_ms,
    MIN(timestamp) AS first_placement,
    MAX(timestamp) AS last_placement
FROM user_actions
WHERE blob1 = 'pixel_placement'
    AND timestamp >= NOW() - INTERVAL '30' DAY
GROUP BY user_id, device_type, user_type
ORDER BY total_placements DESC
LIMIT 50;

-- 10. Mobile vs Desktop comparison
SELECT
    CASE
        WHEN blob2 = 'mobile' THEN 'Mobile'
        WHEN blob2 = 'desktop' THEN 'Desktop'
        ELSE 'Other'
    END AS platform,
    COUNT(*) AS placements,
    COUNT(DISTINCT indexes[1]) AS unique_users,
    ROUND(AVG(double3), 2) AS avg_time_to_first_ms,
    ROUND(AVG(double4), 2) AS avg_session_duration_ms,
    ROUND(AVG(double5), 2) AS avg_placements_per_session
FROM user_actions
WHERE blob1 = 'pixel_placement'
    AND timestamp >= NOW() - INTERVAL '7' DAY
    AND blob2 IN ('mobile', 'desktop')
GROUP BY platform
ORDER BY placements DESC;

-- 11. Authentication completion tracking
SELECT
    blob2 AS device_type,
    COUNT(*) AS auth_completions,
    ROUND(AVG(double1), 2) AS avg_auth_duration_ms,
    ROUND(quantile(0.9)(double1), 2) AS p90_auth_duration_ms
FROM user_actions
WHERE blob1 = 'user_session'
    AND blob2 = 'auth_complete'
    AND timestamp >= NOW() - INTERVAL '7' DAY
GROUP BY device_type;

-- 12. Conversion funnel (auth to first placement)
WITH auth_events AS (
    SELECT
        indexes[1] AS user_id,
        blob6 AS session_id,
        timestamp AS auth_time
    FROM user_actions
    WHERE blob1 = 'user_session' AND blob2 = 'auth_complete'
        AND timestamp >= NOW() - INTERVAL '7' DAY
),
placements AS (
    SELECT
        indexes[1] AS user_id,
        blob6 AS session_id,
        MIN(timestamp) AS first_placement_time
    FROM user_actions
    WHERE blob1 = 'pixel_placement'
        AND timestamp >= NOW() - INTERVAL '7' DAY
    GROUP BY user_id, session_id
)
SELECT
    COUNT(DISTINCT a.user_id) AS users_completed_auth,
    COUNT(DISTINCT p.user_id) AS users_placed_pixels,
    ROUND(COUNT(DISTINCT p.user_id) * 100.0 / COUNT(DISTINCT a.user_id), 2) AS conversion_rate_percent
FROM auth_events a
LEFT JOIN placements p ON a.user_id = p.user_id AND a.session_id = p.session_id;
