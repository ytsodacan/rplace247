from __future__ import annotations
from typing import TYPE_CHECKING, Tuple, List, Dict, Any, Optional
import json
import datetime
import os
import tkinter as tk
from tkinter import filedialog, messagebox

if TYPE_CHECKING:
    from PIL.Image import Image as ImageType
else:
    try:
        from PIL import Image
        ImageType = Any
    except ImportError:
        Image = None
        ImageType = Any

def rgb_to_hex(rgb: Tuple[int, int, int]) -> str:
    """
    Converts an RGB tuple to a hexadecimal color string.

    Args:
        rgb (tuple): A tuple containing R, G, B integer values (e.g., (255, 255, 255)).

    Returns:
        str: A hexadecimal color string (e.g., "#FFFFFF").
    """
    r, g, b = max(0, min(255, int(rgb[0]))), max(0, min(255, int(rgb[1]))), max(0, min(255, int(rgb[2])))
    return f"#{r:02X}{g:02X}{b:02X}"

def image_to_grid_json(image_path: str, output_json_path: str, target_width: int = 500, target_height: int = 500) -> None:
    """
    Converts a 500x500 image into a grid of hexadecimal color codes and saves it as a JSON file.

    The JSON structure will be:
    {
      "timestamp": "ISO 8601 string",
      "version": "1.0",
      "gridWidth": 500,
      "gridHeight": 500,
      "data": [
        ["#RRGGBB", "#RRGGBB", ...],
        ["#RRGGBB", "#RRGGBB", ...],
        ...
      ]
    }

    Args:
        image_path (str): The path to the input image file.
        output_json_path (str): The path where the output JSON file will be saved.
        target_width (int): The desired width of the grid. Default is 500.
        target_height (int): The desired height of the grid. Default is 500.
    """
    try:
        img: ImageType = Image.open(image_path)

        if img.width != target_width or img.height != target_height:
            print(f"Resizing image from {img.width}x{img.height} to {target_width}x{target_height}...")
            img = img.resize((target_width, target_height), Image.Resampling.LANCZOS)

        img = img.convert("RGB")

        pixels = img.load()

        grid_data: List[List[str]] = []
        for y in range(img.height):
            row: List[str] = []
            for x in range(img.width):
                rgb_color: Tuple[int, int, int] = pixels[x, y]
                row.append(rgb_to_hex(rgb_color))
            grid_data.append(row)

        json_output: Dict[str, Any] = {
            "timestamp": datetime.datetime.now(datetime.timezone.utc).isoformat(timespec='milliseconds'),
            "version": "1.0",
            "gridWidth": target_width,
            "gridHeight": target_height,
            "data": grid_data
        }

        with open(output_json_path, 'w') as f:
            json.dump(json_output, f, indent=2)

        messagebox.showinfo("Success", f"Successfully converted '{os.path.basename(image_path)}' to '{os.path.basename(output_json_path)}'")
        print(f"Successfully converted '{image_path}' to '{output_json_path}'")

    except FileNotFoundError:
        messagebox.showerror("Error", f"Image file not found at '{image_path}'")
        print(f"Error: Image file not found at '{image_path}'")
    except Exception as e:
        messagebox.showerror("Error", f"An error occurred: {e}")
        print(f"An error occurred: {e}")

if __name__ == "__main__":
    if Image is None:
        root = tk.Tk()
        root.withdraw()
        messagebox.showerror("Error", "Pillow library not found. Please install it using: pip install Pillow")
        print("Pillow library not found. Please install it using: pip install Pillow")
        root.destroy()
        exit(1)

    root = tk.Tk()
    root.withdraw()

    image_path: Optional[str] = None
    try:
        image_path = filedialog.askopenfilename(
            title="Select an image file",
            filetypes=[("Image files", "*.png *.jpg *.jpeg *.bmp *.gif"), ("All files", "*.*")]
        )

        if not image_path:
            messagebox.showinfo(title="Cancelled", message="No image file selected. Exiting.")
            print("No image file selected. Exiting.")
        else:
            output_json_filename: str = "output_grid_data.json"
            image_to_grid_json(image_path, output_json_filename)

    except Exception as e:
        messagebox.showerror("Error", f"An unexpected error occurred: {e}")
        print(f"An unexpected error occurred: {e}")

    root.destroy()
